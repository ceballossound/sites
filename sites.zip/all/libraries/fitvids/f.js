(function($) {
	$(document).ready(function() {
		$(".video-container").fitVids();
	});
}(jQuery));

(function($) {
	$(document).ready(function() {
		$(".media-youtube-player").fitVids();
	});
}(jQuery));

(function($) {
	$(document).ready(function() {
		$(".icon icon-generic").fitVids();
	});
}(jQuery));


